#define THREADS_ON 1
#define MAX_DEPTH 10
#define EPSILON 0.001
